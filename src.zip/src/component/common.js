const BoardDomain = "http://localhost:8101"  // React App Server url, port로 변경
const PlayDomain = "http://localhost:8102"  // JSON-Server url port 로 변경 

export {BoardDomain,PlayDomain}