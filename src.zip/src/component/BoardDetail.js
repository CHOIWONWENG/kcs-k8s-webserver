import { useEffect, useState } from "react";  
import { useParams, Link } from "react-router-dom";
import { BoardDomain} from "./common";
import { useNavigate } from "react-router-dom";
import { useRef } from "react";

export default function BoardDetail( ) {
    const titleStyle = {
        fontSize: '3rem', // Increased the font size to 3 times the default size
        textDecoration: 'none', // Removing underline
        
      };

    const [board, setBoard] = useState({
        "id": 0,
        "title": null,
        "content": null,
        "writer": 0
    });

    const {id} = useParams(); 
    const navigate = useNavigate();

    const titleRef = useRef(null);
    const writerRef = useRef(null); 
    const contentRef = useRef(null); 

    useEffect( ()=>  {
        console.log(id); 
        fetch(`${BoardDomain}/board/${id}`) 
        .then( res => { return res.json() } ) 
        .then( data => { console.log(data); setBoard( data ) } );
    }, [id]) ; 
 
    function updateBoard(){
        board.titleRef = titleRef.current.value; 
        board.writer = titleRef.current.value; 
        board.content = contentRef.current.value; 
        let newBoard = { ...board }
         
        fetch(`${BoardDomain}/board/${id}`,
        { 
                method : "Put" ,   // 갱신을 위해 Put Method 로 요청 
                headers : {
                'Content-Type' : "application/json",
                },
                body : JSON.stringify( 
                    newBoard
								) 
        }).then( res => {
            if (res.ok ){
                alert(  "수정 성공 "); 
                setBoard(newBoard) ;    //state 변경으로 화면 갱신 
            }
        }
        )
    }
    function deleteBoard(){
        if (window.confirm("정말로 삭제하시겠습니까?")) {

        fetch(`${BoardDomain}/students/${id}`, 
            { 
                method:"Delete" , 
                headers : {
                'Content-Type' : "application/json",
                },   
            }
        ).then( () => 
            {  navigate('/board'); }
        )
      }
    }
     return (
        <div> 
            <table border={1}>
            <caption className="title"><Link to='/' style={titleStyle}> 상세 게시판 </Link></caption>
            <tbody>
                <tr>
                    <th>번호</th>
                    <th>제목</th>
                    <th>내용</th>
                    <th>작성자</th>
                    <th>수정하려면 새 값을 입력하고 버튼 클릭</th>
                    <th>삭제하려면 삭제버튼을 클릭하세요</th></tr>
                <tr key={board.id}> 
                    <td>{board.id}</td>
                    <td>{board.title}</td> 
                    <td>{board.content}</td>
                    <td>{board.writer}</td>

                    <td>
                        <input type="number"   min='0'  max='100' ref={mathScoreRef} />
                        <button onClick={updateBoard}>수정</button>
                    </td> 

                    <td><button onClick={deleteBoard}>Delete</button></td>
                </tr> 
            </tbody>
            </table>
        </div>
     );
}