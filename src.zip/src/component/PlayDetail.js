import { useEffect, useState } from "react";  
import { useParams, Link } from "react-router-dom";
import { PlayDomain} from "./common";
import { useNavigate } from "react-router-dom";
import { useRef } from "react";

export default function PlayDetail( ) {
    const titleStyle = {
        fontSize: '3rem', // Increased the font size to 3 times the default size
        textDecoration: 'none', // Removing underline
        
      };

    const [play, setPlay] = useState({
        "id": 0,
        "name": null,
        "grade": 0
    });

    const navigate = useNavigate();
    const {id} = useParams(); 
    const mathScoreRef = useRef(0) ;

    useEffect( ()=>  {
        console.log(id); 
        fetch(`${PlayDomain}/playlist/${id}`) 
        .then( res => { return res.json() } ) 
        .then( data => { console.log(data); setPlay( data ) } );
    }, [id]) ; 
 
    function updatePlay(){
        play.marks.maths = mathScoreRef.current.value; 
        let newPlay = { ...play }
         
        fetch(`${PlayDomain}/playlist/${id}`,
        { 
                method : "Put" ,   // 갱신을 위해 Put Method 로 요청 
                headers : {
                'Content-Type' : "application/json",
                },
                body : JSON.stringify( 
                    newPlay
		) 

        }).then( res => {
            if (res.ok ){
                alert(  "수정 성공 "); 
                setPlay(newPlay) ;    //state 변경으로 화면 갱신 
            }
        }
        )
    }
    function deletePlay(){
        if (window.confirm("정말로 삭제하시겠습니까?")) {

        fetch(`${PlayDomain}/playlist/${id}`, 
            { 
                method:"Delete" , 
                headers : {
                'Content-Type' : "application/json",
                },   
            }
        ).then( () => 
            {  navigate('/playlist'); }
        )
      }
    }
     return (
        <div> 
            <table border={1}>
            <caption className="title"><Link to='/' style={titleStyle}> 상세 게시판 </Link></caption>
            <tbody>
                <tr><th>학번</th><th>이름</th><th>수학점수</th>
										<th>수정하려면 새 값을 입력하고 버튼 클릭</th>
										<th>삭제하려면 삭제버튼을 클릭하세요</th></tr>
                <tr key={play.id}> 
                    <td>{play.id}</td><td>{play.name}</td> 
                    <td>{play.marks.maths} </td>
                    <td><input type="number"   min='0'  max='100' ref={mathScoreRef} />
                    <button onClick={updatePlay} >수정</button>
                    </td> 
                    <td><button onClick={deletePlay}>Delete</button></td>
                </tr> 
            </tbody>
            </table>
        </div>
     );
}